<!DOCTYPE >
<html lang="en">
<head>
    <title>Oz Doller | Returns Policy</title>
    <?php include_once("master/plugin.php") ?>
<!--    <style type="text/css">-->
<!--        .return_main_div{-->
<!--            margin-top:40px;-->
<!--            width:100%;-->
<!--            overflow: hidden;-->
<!--            background-color: #cccccc2e;-->
<!---->
<!--        }-->
<!--        .return_heading{-->
<!--            background-color:#ffffff !important;-->
<!--            color: #86bc43 !important;-->
<!--            /*border-bottom:1px solid #86bc43 !important;*/-->
<!--        }-->
<!--        .return_heading a{-->
<!--            text-decoration: none;-->
<!--        }-->
<!--        .heading_section_return{-->
<!--            padding-bottom: 10px;-->
<!--            padding-top: 10px;-->
<!---->
<!--        }-->
<!--        @media screen and (min-width: 320px) and (max-width: 767px){-->
<!--            .card{-->
<!--                margin-top: 10px;-->
<!--            }-->
<!--        }-->
<!--    </style>-->
</head>
<body>
<?php include_once("master/header.php") ?>
<section class="product_maincontainer">
    <div class="product_section">
        <div class="main_heading contact_head">
            <div class="main_head_txt">
                Return Policy
            </div>
            <div class="organic_border">
                <span class="organic_icons"></span>
            </div>
        </div>
        <div class="container">
<!--            <section class="return_main_div">-->
<!--                <div class="container">-->
<!--                    <div class="">-->
<!--                        <div class="heading_section_return">-->
<!--                            <div class="main_heading">-->
<!--                                <div class="main_head_txt">-->
<!--                                    RETURN POLICY-->
<!--                                </div>-->
<!--                                <div class="siteorigin-widget-tinymce textwidget">-->
<!--                                    {{--<p>This relies upon the strategy you return it back to us, assuming express and followed,--}}-->
<!--                                        {{--your discount will be handled in up to 3 days after we get it back.</p>--}}-->
<!--                                </div>-->
<!--                                <div class="organic_border">-->
<!--                                    <span class="organic_icons"></span>-->
<!--                                </div>-->
<!---->
<!--                            </div>-->
<!--                        </div>-->
<!--                        <div>-->
<!--                            <div class="panel-group" id="accordion">-->
<!--                                <div class="panel panel-default">-->
<!--                                    <div class="panel-heading return_heading">-->
<!--                                        <h4 class="panel-title">-->
<!--                                            <a data-toggle="collapse" data-parent="#accordion" href="#faq_1">-->
<!---->
<!--                                                <span>Q.</span> I'm an International customer, have you received my returned items? </a>-->
<!--                                        </h4>-->
<!--                                    </div>-->
<!--                                    <div id="#faq_1" class="panel-collapse collapse in">-->
<!--                                        <div class="panel-body">Once our distribution center has got your arrival,we'll email you to tell you your discount has been issued. It would-->
<!--                                            then be able to take 5-10 working days for the assets to show up in your record.On the off chance that you've-->
<!--                                            returned more than one request in a similar bundle, please permit up to 24 hours for all backed things to be prepared.The time it takes-->
<!--                                            for your bundle to contact us shifts relying on where you are returning it from.</div>-->
<!--                                    </div>-->
<!--                                </div>-->
<!--                                <div class="panel panel-default">-->
<!--                                    <div class="panel-heading return_heading">-->
<!--                                        <h4 class="panel-title">-->
<!--                                            <a  class="active" data-toggle="collapse" data-parent="#accordion" href="#faq_2">-->
<!--                                                <span>Q.</span>What is your International Returns Policy?</a>-->
<!--                                        </h4>-->
<!--                                    </div>-->
<!--                                    <div id="faq_2" class="panel-collapse collapse">-->
<!--                                        <div class="panel-body">Once our distribution center has got your arrival, we'll email you to tell you your discount has been issued.-->
<!--                                            It would then be able to take 5-10 working days for the assets to show up in your record.On the off chance that-->
<!--                                            you've returned more than one request in a similar bundle, please permit up to-->
<!--                                            24 hours for all backed things to be prepared.The time it takes for your bundle to contact us shifts relying on where-->
<!--                                            you are returning it from.</div>-->
<!--                                    </div>-->
<!--                                </div>-->
<!--                                <div class="panel panel-default">-->
<!--                                    <div class="panel-heading return_heading">-->
<!--                                        <h4 class="panel-title">-->
<!--                                            <a data-toggle="collapse" data-parent="#accordion" href="#faq_3">-->
<!--                                                <span>Q.</span> What should I do if my order hasn't been delivered yet? </a>-->
<!--                                        </h4>-->
<!--                                    </div>-->
<!--                                    <div id="faq_3" class="panel-collapse collapse">-->
<!--                                        <div class="panel-body">Lorem ipsum dolor sit amet, consectetur adipisicing elit,-->
<!--                                            sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad-->
<!--                                            minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea-->
<!--                                            commodo consequat.</div>-->
<!--                                    </div>-->
<!--                                </div>-->
<!--                                <div class="panel panel-default">-->
<!--                                    <div class="panel-heading return_heading">-->
<!--                                        <h4 class="panel-title">-->
<!--                                            <a  class="active" data-toggle="collapse" data-parent="#accordion" href="#faq_2">-->
<!--                                                <span>Q.</span> How can I get a new returns note? </a>-->
<!--                                        </h4>-->
<!--                                    </div>-->
<!--                                    <div id="faq_2" class="panel-collapse collapse">-->
<!--                                        <div class="panel-body">Lorem ipsum dolor sit amet, consectetur adipisicing elit,-->
<!--                                            sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad-->
<!--                                            minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea-->
<!--                                            commodo consequat.</div>-->
<!--                                    </div>-->
<!--                                </div>-->
<!--                                <div class="panel panel-default">-->
<!--                                    <div class="panel-heading return_heading">-->
<!--                                        <h4 class="panel-title">-->
<!--                                            <a data-toggle="collapse" data-parent="#accordion" href="#faq_3">-->
<!--                                                <span>Q.</span>  How can I get a new returns note? </a>-->
<!--                                        </h4>-->
<!--                                    </div>-->
<!--                                    <div id="faq_3" class="panel-collapse collapse">-->
<!--                                        <div class="panel-body">Lorem ipsum dolor sit amet, consectetur adipisicing elit,-->
<!--                                            sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad-->
<!--                                            minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea-->
<!--                                            commodo consequat.</div>-->
<!--                                    </div>-->
<!--                                </div>-->
<!--                            </div>-->
<!--                        </div>-->
<!--                    </div>-->
<!--                </div>-->
<!--            </section>-->
            <div class="terms_block">
                <div class="card-body">
                    <p class="p_txt">In the course of registering for and availing various services we provide from
                        time to time through our website www.gribee.com ("Website", telephone search, SMS and WAP)
                        or any other medium in which gribee may provide services (collectively referred to as
                        "Media") you may be required to give your name, residence address, workplace address, email
                        address, date of birth, educational qualifications and similar Personal Information
                        ("Personal Information"). The Personal Information is used for three general purposes: to
                        customize the content you see, to fulfill your requests for certain services, and to contact
                        you about our services via including but not limited to email's, sms’s and other means of
                        communication. Unless otherwise stated explicitly, this Policy applies to Personal
                        Information as disclosed on any of the Media.</p>
                    <hr>

                    <p class="p_txt">
                        We are committed to protecting the privacy and confidentiality of all Personal Information
                        that you may share as a user of Media In furtherance thereof, we have this policy to
                        demonstrate our good faith.

                    </p>
                    <hr>
                    <p class="p_txt">
                        This policy does not apply to the practices of organizations that we do not own or to people
                        that we do not employ or manage.</p>
                    <hr>


                    <p class="p_txt">
                        Personal Information will be kept confidential and will be used for our research, marketing,
                        and strategic client analysis objectives and other internal business purposes only. We do
                        not sell or rent Personal Information except that in case you are a customer of our search
                        services through any of the Media, your Personal Information shall be shared with our
                        subscribers/advertisers and you shall be deemed to have given consent to the same. Further,
                        the subscribers / advertisers who are listed with us, may call you, based on the query or
                        enquiry that you make with us, enquiring about any</p>
                    <hr>
                    <p class="p_txt">
                        Product / Service or</p>

                    <p class="p_txt">
                        Product / Service of any subscriber / advertiser or
                    </p>

                    <p><b>Other operational terms</b></p>
                    <hr>

                    <p class="p_txt">
                        In case of orders where offers are applied the terms associated with individual offers will
                        take precedence.</p>
                    <p class="p_txt">We will share Personal Information only under one or more of the following
                        circumstances: - If we have your consent or deemed consent to do so - If we are compelled by
                        law (including court orders) to do so</p>
                    <hr>
                    <p class="p_txt">
                        In furtherance of the confidentiality with which we treat Personal Information we have put
                        in place appropriate physical, electronic, and managerial procedures to safeguard and secure
                        the information we collect online.
                    </p>
                    <hr>
                    <p class="p_txt">We give you the ability to edit your account information and preferences at any
                        time, including whether you want us to contact you about new services. To protect your
                        privacy and security, we will also take reasonable steps to verify your identity before
                        granting access or making corrections.</p>
                    <hr>
                    <p class="p_txt">You acknowledge that you are disclosing Personal Information voluntarily. Prior
                        to the completion of any registration process on our website or prior to availing of any
                        services offered on our website if you wish not to disclose any Personal Information you may
                        refrain from doing so; however if you don't provide information that is requested, it is
                        possible that the registration process would be incomplete and/or you would not be able to
                        avail of the our services.</p>
                    <hr>
                    <p class="p_txt">If you are our corporate customer, it is possible that we have entered into a
                        contract with you for non-disclosure of confidential information. This Policy shall not
                        affect such a contract in any manner.</p>
                    <hr>
                    <p class="p_txt">If you have questions or concerns about these privacy policies; please send us
                        an email at www.gribee.com</p>
                </div>
            </div>
        </div>
    </div>
</section>
<?php include_once("master/footer.php") ?>
</body>
